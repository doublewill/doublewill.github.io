<?php
date_default_timezone_set('PRC');;
$callback = isset($_GET['callback']) ? $_GET['callback'] : '';
$methods = isset($_GET['methods']) ? $_GET['methods'] : '';
$methods = explode('_', $methods);

function getMicrotime(){
  list($usec, $sec) = explode(" ", microtime());
  $usec = (int)((float)$usec * 1000);
  $sec = (float)$sec * 1000;
  return $sec + $usec;
}

$json = array(
  'retCode' => '0',
  'resMsg' => null,
  'sysTime' => '' . getMicrotime(),
);

$result = array();

if (in_array('time', $methods)) {
  $result['time'] = getMicrotime();
}

if (in_array('byhy', $methods)) {
  $result['byhy'] = array(
    "value" => mt_rand(10000000, 20000000),
    "percent" => mt_rand(0, 100)
  );
}

if (in_array('ljjh', $methods)) {
  $result['ljjh'] = mt_rand(30000000, 40000000);
}

//用户规模
if (in_array('yhgm', $methods)) {
  $result['yhgm'] = array(
    'drhy' => mt_rand(123456, 876543),
    'drxzyh' => mt_rand(123456, 87654320),
    'drxzjh' => mt_rand(123456, 8765430),
    'dyxzjh' => mt_rand(123456, 87654320),
  );
}

if (in_array('fourgyhstl', $methods)) {
  $result['fourgyhstl'] = mt_rand(2000, 9000) / 100;
}

if (in_array('zshyym', $methods)) {
  $result['zshyym'] =  array(
    array('name' => '首页', 'value' => mt_rand(100000, 876432)),
    array('name' => '充值', 'value' => mt_rand(100000, 876432)),
    array('name' => '签到', 'value' => mt_rand(100000, 876432)),
    array('name' => '查流量', 'value' => mt_rand(100000, 876432)),
    array('name' => '查账单', 'value' => mt_rand(100000, 876432)),
    array('name' => '热销', 'value' => mt_rand(100000, 876432)),
    array('name' => '流量专区', 'value' => mt_rand(100000, 876432)),
    array('name' => '业务办理', 'value' => mt_rand(100000, 876432)),
    array('name' => '套餐余量', 'value' => mt_rand(100000, 876432)),
    array('name' => '优惠券', 'value' => mt_rand(100000, 876432)),
  );
}

if (in_array('drqd', $methods)) {
  $result['drqd'] = array(
    'cishu' => mt_rand(10000, 800000),
    'renjun' => mt_rand(100, 8000) / 100,
  );
}

if (in_array('pjsysc', $methods)) {
  $result['pjsysc'] = mt_rand(1000, 876432);
}

if (in_array('zxyh', $methods)) {
  $result['zxyh'] = array(
    array('city' => '东营', 'hyrs' => mt_rand(1000, 8764320), 'zxrs' => mt_rand(1000, 8764320)),
    array('city' => '临沂', 'hyrs' => mt_rand(1000, 8764320), 'zxrs' => mt_rand(1000, 8764320)),
    array('city' => '威海', 'hyrs' => mt_rand(1000, 8764320), 'zxrs' => mt_rand(1000, 8764320)),
    array('city' => '德州', 'hyrs' => mt_rand(1000, 8764320), 'zxrs' => mt_rand(1000, 8764320)),
    array('city' => '日照', 'hyrs' => mt_rand(1000, 8764320), 'zxrs' => mt_rand(1000, 8764320)),
    array('city' => '枣庄', 'hyrs' => mt_rand(1000, 8764320), 'zxrs' => mt_rand(1000, 8764320)),
    array('city' => '泰安', 'hyrs' => mt_rand(1000, 8764320), 'zxrs' => mt_rand(1000, 8764320)),
    array('city' => '济南', 'hyrs' => mt_rand(8764319, 8764320), 'zxrs' => mt_rand(8764319, 8764320)),
    array('city' => '济宁', 'hyrs' => mt_rand(1000, 8764320), 'zxrs' => mt_rand(1000, 8764320)),
    array('city' => '淄博', 'hyrs' => mt_rand(1000, 8764320), 'zxrs' => mt_rand(1000, 8764320)),
    array('city' => '滨州', 'hyrs' => mt_rand(1000, 8764320), 'zxrs' => mt_rand(1000, 8764320)),
    array('city' => '潍坊', 'hyrs' => mt_rand(1000, 8764320), 'zxrs' => mt_rand(1000, 8764320)),
    array('city' => '烟台', 'hyrs' => mt_rand(1000, 8764320), 'zxrs' => mt_rand(1000, 8764320)),
    array('city' => '聊城', 'hyrs' => mt_rand(1000, 8764320), 'zxrs' => mt_rand(1000, 8764320)),
    array('city' => '莱芜', 'hyrs' => mt_rand(1000, 8764320), 'zxrs' => mt_rand(1000, 8764320)),
    array('city' => '菏泽', 'hyrs' => mt_rand(1000, 8764320), 'zxrs' => mt_rand(1000, 8764320)),
    array('city' => '青岛', 'hyrs' => mt_rand(1000, 8764320), 'zxrs' => mt_rand(1000, 8764320)),
  );
}

//第二屏
//当月查询
if (in_array('dyfw', $methods)) {
  $result['dyfw'] =  array(
    array('name' => '查账单', 'value' => mt_rand(1000, 87643200)),
    array('name' => '查流量', 'value' => mt_rand(1000, 876432)),
    array('name' => '查积分', 'value' => mt_rand(1000000, 8764320)),
    array('name' => '查详单', 'value' => mt_rand(100000, 87643200)),
    array('name' => '其他查询', 'value' => mt_rand(1000000, 8764320)),
  );
}

//当月办理量
if (in_array('dybll', $methods)) {
 $result['dybll'] = array(
  array(
    'name' => '流量',
    'unit' => '笔',
    'target' =>mt_rand(100000, 876432),
    'current' => mt_rand(100000, 876432),
    'tradePrice' => mt_rand(100000, 876432),
    'tradeUnit' => '元',
    ),
  array(
    'name' => '套餐', 'unit' => '笔',
    'target' => mt_rand(100000, 876432),
    'current' => mt_rand(100000, 876432),
    'tradePrice' => mt_rand(100000, 876432),
    'tradeUnit' => '元',
    ),
  array(
    'name' => '宽带', 'unit' => '笔',
    'target' => mt_rand(100000, 876432),
    'current' => mt_rand(100000, 876432),
    ),
  array(
    'name' => '数字化', 'unit' => '笔',
    'target' => mt_rand(100000, 876432),
    'current' => mt_rand(100000, 876432),
    'tradePrice' => mt_rand(100000, 876432),
    'tradeUnit' => '元',
    ),
  array(
    'name' => '充值', 'unit' => '元',
    'target' => mt_rand(1000000, 87643000),
    'current' => mt_rand(10000000, 87643000),
    'tradePrice' => mt_rand(100000, 876432),
    'tradeUnit' => '元',
    ),
  );
}

//常规活动
if (in_array('cghd', $methods)) {
  $result['cghd'] =  array(
    array(
        array(
          'name' => '签到',
          'value' => mt_rand(1000000, 876403200),
          'iconsrc' => 'upload/icon-signup.png',
        ),
        array(
          'name' => '流量月月领',
          'value' => mt_rand(1000000, 876043200),
          'iconsrc' => 'upload/icon-flux.png',
        ),
    ),
    array(
        array(
          'name' => '当月发卡量',
          'value' => mt_rand(1000000, 876403200),
          'unit' => '张',
          'iconsrc' => 'upload/icon-card.png',
      ),
        array(
          'name' => '当月激活率',
          'value' => mt_rand(0, 100),
          'unit' => '%',
          'iconsrc' => 'upload/icon-active.png',
      ),
    ),
  );
}

//业务营销
if (in_array('ywyx', $methods)) {
  $result['ywyx'] =  array(
      array(
        'name' => '“任我享”降费半年包',
        'data' => array(
          array(
            'type' => '本月笔数',
            'value' => mt_rand(100, 876).'万',
            'unit' => '笔'
          ),
          array(
            'type' => '本月金额',
            'value' => mt_rand(100, 876).'万',
            'unit' => ''
          ),
          array(
            'type' => '累计笔数',
            'value' => mt_rand(100, 876).'万',
            'unit' => '笔'
          ),
          array(
            'type' => '累计金额',
            'value' => mt_rand(100, 876).'万',
            'unit' => ''
          ),
        ),
        'unit' => '元',
        'icon' => 'upload/market-bowel.png',
      ),
      array(
        'name' => '任我看',
        'data' => array(
          array(
            'type' => '本月笔数',
            'value' => mt_rand(100, 876).'万',
          ),
          array(
            'type' => '累计笔数',
            'value' => mt_rand(100, 876).'万',
          ),
        ),
        'unit' => '笔',
        'icon' => 'upload/market-bowel.png',
      ),
      array(
        'name' => '亲密付',
        'data' => array(
          array(
            'type' => '昨日笔数',
            'value' => mt_rand(100, 876).'万',
            'unit' => '笔'
          ),
          array(
            'type' => '昨日金额',
            'value' => mt_rand(100, 876).'万',
            'unit' => '元'
          ),
          array(
            'type' => '本月笔数',
            'value' => mt_rand(100, 876).'万',
            'unit' => '笔'
          ),
          array(
            'type' => '本月金额',
            'value' => mt_rand(100, 876).'万',
            'unit' => '元'
          ),
        ),
        'unit' => '元',
        'icon' => 'upload/market-bowel.png',
      ),

      array(
        'name' => '流量转赠',
        'data' => array(
          array(
            'type' => '昨日笔数',
            'value' => mt_rand(100, 876).'万',
          ),
          array(
            'type' => '昨日转增流量',
            'value' => mt_rand(100, 876),
            'unit' => 'M'
          ),
          array(
            'type' => '本月笔数',
            'value' => mt_rand(100, 876).'万',
          ),
          array(
            'type' => '本月转增流量',
            'value' => mt_rand(100, 876),
            'unit' => 'M'
          ),
        ),
        'unit' => '笔',
        'icon' => 'upload/market-bowel.png',
      ),
  );
}

//产品迭代规划
if (in_array('cpddjh', $methods)) {
  $result['cpddjh'] =  array(
      array(
        'release' => '2017/1/4',
        'version' => '4.5.0',
        'changlog_new' =>
        '首页新增地市营销内容展示楼层|首页新增地市营销内容展示楼层|首页新增娱乐内容展示楼层|手机桌面新增widget快捷功能通知栏|新增一键登录功能|新增一键登录功能|新增一键登录功能|新增一键登录功能',

        'changlog_fix' => '首页新增地市营销内容展示楼层|首页新增地市营销内容展示楼层|首页新增娱乐内容展示楼层|手机桌面新增widget快捷功能通知栏|新增一键登录功能|新增一键登录功能|新增一键登录功能|新增一键登录功能'
        ),

      array(
        'release' => '2017/2/4',
        'version' => '2.5.0',
        'changlog_new' =>
        '新增生活专区|新增生活专区|安卓新增调用系统短信权限|安卓新增H5视频全屏播放功能|安卓新增应用市场渠道统计',
        'changlog_fix' =>
        "新增生活专区|新增生活专区|安卓新增调用系统短信权限|安卓新增H5视频全屏播放功能|安卓新增应用市场渠道统计"
        ),
      array(
        'release' => '2017/3/4',
        'version' => '3.5.0',
        'changlog_new' =>
        '首页楼层动态配置优化|我的移动布局结构优化|欢迎页弹窗随机轮播优化|已开业务分类查询优化',
        'changlog_fix' =>
        '首页楼层动态配置优化|我的移动布局结构优化|欢迎页弹窗随机轮播优化|已开业务分类查询优化'
        )
    );
}

$json['retObj'] = $result;

if ($callback) {
  @header('Content-type: text/javascript');
  echo $callback . ' && ' . $callback . '(';
} else {
  @header('Content-type: application/json');
}

echo json_encode($json );

if ($callback) {
  echo ')';
}
