/* eslint-disable comma-dangle */
(function(window) {
  'use strict';

  var dependencies = [
    'geojson',
  ];

  var data = [
    'time',
    's2Service',
    's2Handle',
    's2Activity',
    's2Market',
    's2Build',
  ];

  var modules = [
    'clock',
    's2-service',
    's2-handle',
    's2-activity',
    's2-market',
    's2-build',
  ];
  var screen = window.common.getScreen(dependencies, data, modules);
  var requirePromise = window.common.requirePromise;

  Promise.resolve()
    .then(screen.loadDependencies.bind(screen))
    .then(screen.startDataWatch.bind(screen))
    .then(function() {
      // return require('clock').watch();
    })
    .then(screen.queryData.bind(screen))
    .then(screen.loadModules.bind(screen))
    .then(function() {
      return require('resize').bind('#js-container');
    })
    .catch(function(e) {
      console.trace(e);
    });
})(this);
