/* eslint-disable comma-dangle */
(function(root, factory) {
  'use strict';

  if (typeof define === 'function' && define.amd) {
    define([], factory(root));
  } else if (typeof module === 'object' && module.exports) {
    module.exports = factory(root);
  } else {
    root.returnExports = factory(root);
  }
})(this, function(window) {
  'use strict';

  var utils = {};
  utils.noop = function() {};

  utils.type = function(obj) {
    return Object.prototype.toString.call(obj).match(/^\[object (.+?)\]$/)[1].toLowerCase();
  };

  utils.identity = function(value) { return value; };

  utils.toArray = function(obj) {
    return Array.prototype.slice.call(obj);
  };

  utils.buildQuery = function(data) {
    var params = [];
    for (var key in data) {
      if (data.hasOwnProperty(key)) {
        params.push(encodeURIComponent(key) + '=' + encodeURIComponent(data[key]));
      }
    }
    return params.join('&');
  };

  utils.getJSONP = function(url, data, callback) {
    if (arguments.length === 2) {
      callback = data;
      data = {};
    }
    callback = callback || utils.noop;

    var now = Math.max(Date.now(), 268435456);
    var callbackName = 'jsonp_' + Math.floor(now + Math.random() * now).toString(16).slice(-8);
    var head = document.head;
    var script = document.createElement('script');
    var queryString = utils.buildQuery(data);

    if (queryString) {
      url += (url.indexOf('?') > -1 ? '&' : '') + queryString;
    }

    if (url.indexOf('=?') === -1) {
      url += (url.indexOf('?') > -1 ? '&' : '') + 'callback=' + callbackName;
    } else {
      url = url.replace('=?', '=' + callbackName);
    }
    script.src = url;
    window[callbackName] = function(data) {
      delete window[callbackName];
      callback(data);
    };
    var load = function(e) {
      head.removeChild(script);
    };
    script.addEventListener('load', load, false);
    script.addEventListener('error', load, false);
    head.appendChild(script);
  };

  utils.ajaxJSON = function(url, data, callback) {
    if (arguments.length === 2) {
      callback = data;
      data = {};
    }
    callback = callback || utils.noop;
    var queryString = utils.buildQuery(data);

    if (queryString) {
      url += (url.indexOf('?') > -1 ? '&' : '') + queryString;
    }
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.open('GET', url, true);
    xmlhttp.onreadystatechange = function() {
      if (
        xmlhttp.readyState === XMLHttpRequest.DONE &&
        xmlhttp.status === 200
      ) {
        try {
          callback(JSON.parse(xmlhttp.responseText));
        } catch (_) {}
      }
    };
    xmlhttp.send();
  };

  utils.getJSON = function(url, callback) {
    var isJSONP = url.indexOf('=?') > -1;

    if (isJSONP) {
      utils.getJSONP(url, {}, callback);
    } else {
      utils.ajaxJSON(url, {}, callback);
    }
  };

  utils.on = function(target, eventTypes, eventListener, useCapture) {
    if (utils.type(eventTypes) !== 'array') {
      eventTypes = eventTypes.split(' ');
    }

    eventTypes.forEach(function(eventType) {
      target.addEventListener(eventType, eventListener, !!useCapture);
    });
  };

  utils.off = function(target, eventTypes, eventListener, useCapture) {
    if (utils.type(eventTypes) !== 'array') {
      eventTypes = eventTypes.split(' ');
    }

    eventTypes.forEach(function(eventType) {
      target.removeEventListener(eventType, eventListener, !!useCapture);
    });
  };

  utils.pad = function(s, len, padString) {
    padString = padString || '0';
    return (padString.repeat(len) + s).slice(-len);
  };

  utils.camelCase = function(s) {
    return s.replace(/-([^-]+?)/g, function($0, $1) {
      return $1.toUpperCase();
    });
  };

  utils.dom = function(selector, context) {
    context = context || document;
    if (selector.match(/^#[\w-]+$/)) {
      return [document.getElementById(selector.slice(1))];
    } else if (selector.match(/^[\w-]+$/)) {
      return utils.toArray(context.getElementsByTagName(selector));
    }

    return utils.toArray(context.querySelectorAll(selector));
  };

  utils.each = function(obj, callback) {
    if (obj.length) {
      return Array.prototype.forEach.call(obj, callback);
    } else {
      return Object.keys(obj).forEach(function(key) {
        callback(key, obj[key], obj);
      });
    }
  };

  utils.random = function(low, high) {
    return low + Math.floor(Math.random() * (high - low));
  };
  utils.ramdom = utils.random; // miss spelled.

  utils.formatNum = function(n) {
    if (n === undefined) {
      return '-'
    }
    return ('' + n).replace(/(\d)(?=(\d{3})+$)/g, '$1,');
  };

  utils.scientificNum = function(n) {
    if (n === undefined) {
      return '-'
    }

    if (n > 10e7) {
      return (n / 10e7).toFixed(2) + '亿';
    } else if (n > 10e4) {
      return (n / 10e3).toFixed(2) + '万';
    } else {
      return n;
    }
  };

  utils.encodeHTML = function(s) {
    return s
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/\s/g, '&nbsp;')
      .replace(/\'/g, '&#39;')
      .replace(/\"/g, '&quot;');
  };

  utils.ts = function() {
    return window.performance.now();
  };

  utils.sum = function(arr, key) {
    return arr.reduce(function(prev, cur) {
      return prev + (key ? cur[key] : cur);
    }, 0);
  };

  utils.max = function(arr, key) {
    var valueArr = key ?
      arr.map(function(item) {
        return item[key];
      }) :
      arr;
    return Math.max.apply(Math, valueArr);
  };

  utils.min = function(arr, key) {
    var valueArr = key ?
      arr.map(function(item) {
        return item[key];
      }) :
      arr;
    return Math.min.apply(Math, valueArr);
  };


  return utils;
});
