/* eslint-disable comma-dangle */
(function(root, factory) {
  'use strict';

  if (typeof define === 'function' && define.amd) {
    define([], factory(root));
  } else if (typeof module === 'object' && module.exports) {
    module.exports = factory(root);
  } else {
    root.returnExports = factory(root);
  }
})(this, function(window) {
  'use strict';

  var _ = require('utils');
  var globals = require('globals');
  var document = window.document;

  var mod = {
    elements: {
      times: document.getElementById('js-start-times'),
      average: document.getElementById('js-start-average'),
    },
    data: {
      last: {},
      current: {},
    },
    frequency: 5 * 1000,
  };

  function render() {
    if (mod.data.current.renjun) {
      mod.elements.average.innerHTML = mod.data.current.renjun.toFixed(1);
    }
    if (mod.data.current.cishu) {
      mod.elements.times.innerHTML = _.formatNum(mod.data.current.cishu);
    }
  }

  mod.watch = function() {
    (function watch() {

      window.setTimeout(watch, mod.frequency);
      mod.data.current = globals.userStartTimes && globals.userStartTimes.data;
      if (JSON.stringify(mod.data.current) !== JSON.stringify(mod.data.last)) {
        render();
        mod.data.last = mod.data.current;
        mod.time = Date.now();
      }
    })();
  };

  return mod;
});
