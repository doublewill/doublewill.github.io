/* eslint-disable comma-dangle */
(function(root, factory) {
  'use strict';

  if (typeof define === 'function' && define.amd) {
    define([], factory(root));
  } else if (typeof module === 'object' && module.exports) {
    module.exports = factory(root);
  } else {
    root.returnExports = factory(root);
  }
})(this, function(window) {
  'use strict';

  var _ = require('utils');
  var globals = require('globals');
  var document = window.document;
  var $ = window.$;

  var mod = {
    elements: {
      container: document.getElementById('js-activity-container'),
      card: document.getElementById('js-card-container'),
    },
    data: {
      last: {},
      current: {},
    },
    frequency: 10 * 1000,
  };

  function dataFormat(n) {
    if (n > 1e8) {
      return (n / 1e8).toFixed(2) + '亿';
    } else if (n > 10e6) {
      return (n / 10e3).toFixed(2) + '万';
    } else {
      return _.formatNum(n)
    }
  };

  window.setInterval(function() {
    $('.activity-content').toggle();
  }, 3000);

  function renderActivityContent(datas, selectors) {
      datas.forEach(function(data, index) {
         var html = data.map(function(data, index) {
              var type = data.unit ? data.unit : '';
              return [
                  '<li class="activity-list-item">',
                    '<div class="info signup">',
                      '<div class="icon">',
                        (data.iconsrc ? '<img src="' + data.iconsrc + '">' : ''),
                      '</div>',
                      '<span class="name">' + data.name + '</span>',
                    '</div>',
                    '<strong class="counter">' + dataFormat(data.value) + type + '</strong>',
                  '</li>'
                ].join('');
            }).join('');
         selectors[index].innerHTML = html;
      });
  }

  function render() {
    renderActivityContent(mod.data.current, [mod.elements.container, mod.elements.card])
  }

  mod.watch = function() {
    (function watch() {
      window.setTimeout(watch, mod.frequency);
      mod.data.current = globals.s2Activity && globals.s2Activity.data;
      if (JSON.stringify(mod.data.current) !== JSON.stringify(mod.data.last)) {
        render();
        mod.data.last = mod.data.current;
        mod.time = Date.now();
      }
    })();
  };
  return mod;
});
