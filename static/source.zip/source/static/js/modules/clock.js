/* eslint-disable comma-dangle */
(function(root, factory) {
  'use strict';

  if (typeof define === 'function' && define.amd) {
    define([], factory(root));
  } else if (typeof module === 'object' && module.exports) {
    module.exports = factory(root);
  } else {
    root.returnExports = factory(root);
  }
})(this, function(window) {
  'use strict';

  var _ = require('utils');
  var globals = require('globals');
  var document = window.document;

  var mod = {
    elements: [],
    data: {
      last: {},
      current: {},
    },
    frequency: 0.5 * 1000,
  };

  var weeks = '日一二三四五六'.split('');

  var setTimeout = window.setTimeout;

  function pad(s) {
    return _.pad(s, 2);
  }

  var typeFormaters = {
    'full-year': null,
    month: function(month) {
      return month + 1;
    },
    date: null,
    day: function(day) {
      return weeks[day];
    },
    hours: pad,
    minutes: pad,
    seconds: pad
  };
  var types = Object.keys(typeFormaters);
  var clockInited = false;

  function init() {
    if (clockInited) {
      return;
    }
    _.each(typeFormaters, function(type) {
      mod.elements[type] = document.getElementById('js-clock-' + type);
    });
    clockInited = true;
  }

  function render() {

    init();
    var date = new Date(Date.now() + globals.TIME_DIFF);
    types.forEach(function(type) {
      var method = _.camelCase('get-' + type);
      var value = date[method]();
      if (mod.data.last[type] !== value) {
        var formater = typeFormaters[type] || _.identity;
        var text = '' + formater(value);

        mod.elements[type.toLowerCase()].innerHTML = text.split('').map(function(char) {
          return '<i>' + char + '</i>';
        }).join('');

        mod.data.last[type] = mod.data.current[type] = value;
      }
    });
  }

  mod.watch = function() {
    (function watch() {
      render();
      setTimeout(watch, mod.frequency);
    })();
  };

  return mod;
});
