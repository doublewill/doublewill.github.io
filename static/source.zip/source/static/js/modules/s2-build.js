/* eslint-disable comma-dangle */
(function(root, factory) {
  'use strict';

  if (typeof define === 'function' && define.amd) {
    define([], factory(root));
  } else if (typeof module === 'object' && module.exports) {
    module.exports = factory(root);
  } else {
    root.returnExports = factory(root);
  }
})(this, function(window) {
  'use strict';

  var _ = require('utils');
  var globals = require('globals');
  var document = window.document;
  var $ = window.$;

  var mod = {
    elements: {
      container: document.getElementById('js-changelog-box'),
    },
    data: {
      last: {},
      current: {},
    },
    frequency: 10 * 1000,
  };


  var container = $(mod.elements.container);
  var width;

  function getBuildInfor(logs) {
    var buildDetail = $('<ul class="build-detail"></ul>');
    logs.forEach(function(log, index) {
      buildDetail.append($('<li class="build-detail-item">' + log + '</li>'));
    })
    return buildDetail
  }

  function render() {
    container.html('');

    mod.data.current.sort(function(versionNew, versionOld) {
        return versionNew.version > versionOld.version
      })
      .forEach(function(data, index) {
        var buildInfoItem =  $('<li class="build-info-item"></li>');
        var html = [
          '<div class="build-phone">',
            '<div class="os-icon">',
              '<span class="os android"></span><span class="os ios"></span>',
            '</div>',
            '<em class="version-number" id="js-version-number">版本： ' + data.version + '</em>',
            '<div class="upload">',
             '<span class="upload-icon"></span>',
              '<span class="upload-date" id="js-upload-date">上线： ' + data.release + '</span>',
            '</div>',
          '</div>',
          '<div class="build-box">',
            '<h3 class="build-title">重点功能</h3>',
            '<dl class="log-info">',
             '<dd class="log-info-item"></dd>',
             '<dd class="log-info-item"></dd>',
             '</dl>',
          '</div>',
       ].join('');

        buildInfoItem.append(html)
        var changeLogNew = getBuildInfor(data.changlog_new.split('|'))
        var changeLogFix = getBuildInfor(data.changlog_fix.split('|'))
        container.append(buildInfoItem);
        var logInfo = $('dd', buildInfoItem);
        logInfo.eq(0).append(changeLogNew);
        logInfo.eq(1).append(changeLogFix);
      });

      width = $('.build-info-item').outerWidth();

      container.css({
        'width': $('.build-info-item').length * 2 * width
      })

      var outerHtml =  container.html();
      container.html(outerHtml + outerHtml);
  }
  function init() {
    var index = 0;
    var buildItem = $('.build-decribe');
    var onIndex;
    window.setInterval(function() {
      ++index;
      index %= (mod.data.current.length + 1);
      onIndex =  index === mod.data.current.length ? 0 : index;
      buildItem.removeClass('current-build').eq(onIndex).addClass('current-build');
      container.animate({
        'marginLeft': - index * width
      }, 500, function() {
        if (index >= mod.data.current.length) {
          container.css({
              'marginLeft': 0
          })
        }
      })
    }, 2000);
  }

  mod.watch = function() {
    (function watch() {
      window.setTimeout(watch, mod.frequency);
      mod.data.current = globals.s2Build && globals.s2Build.data;
      if (JSON.stringify(mod.data.current) !== JSON.stringify(mod.data.last)) {
        mod.data.last = mod.data.current;
        render();
        mod.time = Date.now();
      }
    })();
    init();
  };
  return mod;
});
