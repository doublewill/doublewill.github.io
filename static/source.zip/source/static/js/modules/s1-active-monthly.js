/* eslint-disable comma-dangle */
(function(root, factory) {
  'use strict';

  if (typeof define === 'function' && define.amd) {
    define([], factory(root));
  } else if (typeof module === 'object' && module.exports) {
    module.exports = factory(root);
  } else {
    root.returnExports = factory(root);
  }
})(this, function(window) {
  'use strict';

  var _ = require('utils');
  var globals = require('globals');
  var document = window.document;

  var mod = {
    elements: {
      container: document.getElementById('js-activity-user-monthly'),
      bar: document.getElementById('js-completion-percent-bar'),
      text: document.getElementById('js-completion-percent-text'),
    },
    data: {
      last: {},
      current: {},
    },
    frequency: 10 * 1000,
  };

  function render() {
    var html = [];
    if (mod.data.last.data) {
      html.push('<div>' + _.formatNum(mod.data.last.data.value) + '</div>');
    }
    var currentData = mod.data.current.data;

    html.push('<div>' + _.formatNum(currentData.value) + '</div>');
    mod.elements.container.innerHTML = html.join('');
    mod.elements.bar.style.width = currentData.percent + '%';
    mod.elements.text.innerHTML = (currentData.percent || 0) + '%';
  }

  mod.watch = function() {
    (function watch() {
      window.setTimeout(watch, mod.frequency);
      mod.data.current.data = globals.activityUserMonthly.data;
      if (mod.data.current.data !== mod.data.last.data) {
        render();
        mod.data.last.data = mod.data.current.data;
        mod.data.last.time = Date.now();
      }
    })();
  };
  return mod;
});
