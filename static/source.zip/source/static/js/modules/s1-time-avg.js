/* eslint-disable comma-dangle */
(function(root, factory) {
  'use strict';

  if (typeof define === 'function' && define.amd) {
    define([], factory(root));
  } else if (typeof module === 'object' && module.exports) {
    module.exports = factory(root);
  } else {
    root.returnExports = factory(root);
  }
})(this, function(window) {
  'use strict';

  var _ = require('utils');
  var globals = require('globals');
  var document = window.document;

  var mod = {
    elements: {
      container: document.getElementById('js-time-last'),
    },
    data: {
      last: {},
      current: {},
    },
    frequency: 5 * 1000,
  };

  function render() {
    mod.elements.container.innerHTML = _.formatNum(mod.data.current.data);
  }

  mod.watch = function() {
    (function watch() {
      window.setTimeout(watch, mod.frequency);
      globals.useTimeAvg = globals.useTimeAvg || {};
      globals.useTimeAvg.data = globals.useTimeAvg.data || 0;
      mod.data.current.data = globals.useTimeAvg.data;
      if (mod.data.current.data !== mod.data.last.data) {
        render();
        mod.data.last.data = mod.data.current.data;
        mod.data.last.time = Date.now();
      }
    })();
  };

  return mod;
});
