/* eslint-disable comma-dangle */
(function(root, factory) {
  'use strict';

  if (typeof define === 'function' && define.amd) {
    define([], factory(root));
  } else if (typeof module === 'object' && module.exports) {
    module.exports = factory(root);
  } else {
    root.returnExports = factory(root);
  }
})(this, function(window) {
  'use strict';

  var _ = require('utils');
  var document = window.document;
  var documentElement = document.documentElement;

  var cancelFullScreen = (
    document.cancelFullScreen ||
    document.webkitCancelFullScreen ||
    document.mozCancelFullScreen
    ).bind(document);

  var requestFullScreen = (
    documentElement.requestFullScreen ||
    documentElement.webkitRequestFullScreen ||
    documentElement.mozRequestFullScreen
    ).bind(documentElement);

  var fullscreen = {
    exit: cancelFullScreen,
    enter: requestFullScreen,
    toggle: function() {
      if (document.fullScreen || document.webkitIsFullScreen || document.mozFullScreen) {
        fullscreen.exit();
      } else {
        fullscreen.enter();
      }
    },
    bind: function() {
      _.on(documentElement, 'click', function() {
        if (document.fullScreen || document.webkitIsFullScreen || document.mozFullScreen) {
          return;
        }
        fullscreen.enter();
      });
    }
  };

  return fullscreen;
});
