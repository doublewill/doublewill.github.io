/* eslint-disable comma-dangle */
(function(root, factory) {
  'use strict';

  if (typeof define === 'function' && define.amd) {
    define([], factory(root));
  } else if (typeof module === 'object' && module.exports) {
    module.exports = factory(root);
  } else {
    root.returnExports = factory(root);
  }
})(this, function(window) {
  'use strict';

  var _ = require('utils');
  var globals = require('globals');
  var document = window.document;

  var mod = {
    elements: {
      containerDrhy: document.getElementById('js-scale-drhy'),
      containerDrxzyh: document.getElementById('js-scale-drxzyh'),
      containerDrxzjy: document.getElementById('js-scale-drxzjh'),
      containerDyxzjh: document.getElementById('js-scale-dyxzjh'),
    },
    data: {
      last: {},
      current: {},
    },
    frequency: 5 * 1000,
  };

  function formatNum(number) {
    if (number === undefined) {
       return '-'
    }

    if (number > 10e5) {
      return (number / 10e3).toFixed(2) + '万'
    }
    else {
      return _.formatNum(number)
    }
  }

  function render() {
    mod.elements.containerDrhy.innerHTML = formatNum(mod.data.current.data.drhy);
    mod.elements.containerDrxzyh.innerHTML = formatNum(mod.data.current.data.drxzyh);
    mod.elements.containerDrxzjy.innerHTML = formatNum(mod.data.current.data.drxzjh);
    mod.elements.containerDyxzjh.innerHTML = formatNum(mod.data.current.data.dyxzjh);
  }

  mod.watch = function() {
    (function watch() {
      window.setTimeout(watch, mod.frequency)
      mod.data.current.data = globals.userScale.data;
      if (mod.data.current.data !== mod.data.last.data) {
        render();
        mod.data.last.data = mod.data.current.data;
        mod.data.last.time = Date.now();
      }
    })();
  }
  return mod;
});
