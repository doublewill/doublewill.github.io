/* eslint-disable comma-dangle */
(function(root, factory) {
  'use strict';

  if (typeof define === 'function' && define.amd) {
    define([], factory(root));
  } else if (typeof module === 'object' && module.exports) {
    module.exports = factory(root);
  } else {
    root.returnExports = factory(root);
  }
})(this, function(window) {
  'use strict';

  var mod = {};

  mod.API_BASE = '/bd-api/bigscreen/';

  mod.TIME_DIFF = 0;

  mod.MODULE_MAP = {
    time: {
      method: 'time',
      frequency: Infinity,
    },
    userScale: {
      method: 'yhgm',
      frequency: 5 * 1000,
    },
    activityUserMonthly: {
      method: 'byhy',
      frequency: 10 * 1000,
    },
    activityUserAccumulate: {
      method: 'ljjh',
      frequency: 10 * 1000,
    },
    userStartTimes: {
      method: 'drqd',
      frequency: 10 * 1000,
    },
    useTimeAvg: {
      method: 'pjsysc',
      frequency: 5 * 1000,
    },
    userPic4gyhstl: {
      method: 'fourgyhstl',
      frequency: 24 * 60 * 60 * 1000,
    },
    userPopularPage: {
      method: 'zshyym',
      frequency: 10 * 1000,
    },
    areaActive: {
      method: 'zxyh',
      frequency: 120 * 1000,
    },
    // 第二屏
    // 查询
    s2Service: {
      method: 'dyfw',
      frequency: 50 * 1000,
    },
    s2Handle: {
      method: 'dybll',
      frequency: 30 * 1000,
    },
    s2Activity: {
      method: 'cghd',
      frequency: 10 * 1000,
    },
    s2Market: {
      method: 'ywyx',
      frequency: 5 * 1000,
    },
    s2Build: {
      method: 'cpddjh',
      frequency: 30 * 1000,
    },
  };

  return mod;
});
