/* eslint-disable comma-dangle */
(function(root, factory) {
  'use strict';

  if (typeof define === 'function' && define.amd) {
    define([], factory(root));
  } else if (typeof module === 'object' && module.exports) {
    module.exports = factory(root);
  } else {
    root.returnExports = factory(root);
  }
})(this, function(window) {
  'use strict';
  var _ = require('utils');
  var globals = require('globals');
  var document = window.document;
  var mod = {
    elements: {
      container: document.getElementById('js-handle-container'),
    },
    data: {
      last: {},
      current: {},
    },
    frequency: 10 * 1000,
  };

  var bizTable = ['流量', '套餐', '充值', '数字化', '宽带'];

  function render() {
      var html = bizTable.map(function(biz, index) {
      var data =  mod.data.current.filter(function(data) {
          return  data.name === bizTable[index]
      })[0] || {
        name: '-',
        target: 0,
        current: 0,
        tradePrice: 0,
        tradeUnit: '-'
      };

      var height = 0;
      var className = '';
      var percent = data.current / data.target;
      var bottomInfo;

      if (data.current > data.target) {
          if (data.current < data.target * 1.01)  // 默认超过时，最小显示101%
          {
            percent = 1.01
          }
          height = 140;
          className = 'over-target';
      } else {
        height = percent * 110;
        className = '';
      }

      if (data.tradePrice) {
        bottomInfo =
          '<div class="business-info">' +
            '<span class="count">' + _.scientificNum(data.current) + data.unit + '</span>' +
            '<span class="count">' + _.scientificNum(data.tradePrice) + data.tradeUnit + '</span>' +
          '</div>';
     }
     else {
        bottomInfo =
          '<div class="business-info">' +
            '<span class="count">' + _.scientificNum(data.current) + data.unit + '</span>' +
          '</div>';
      }
      return [
        '<li>',
          '<div class="bars ' + className + '" style="height:' + height + 'px">',
            '<span class="tip">' + parseInt(percent * 100, 10) + '%</span>',
          '</div>',
            '<em class="name">' + data.name + '</em>',
            bottomInfo,
        '</li>'
      ].join('');
    }).join('');
    mod.elements.container.innerHTML = html;
  }

  mod.watch = function() {
    (function watch() {
      window.setTimeout(watch, mod.frequency);
      globals.s2Handle = globals.s2Handle || {};
      globals.s2Handle.data = globals.s2Handle.data || [];
      mod.data.current = globals.s2Handle.data;
      if (JSON.stringify(mod.data.current) !== JSON.stringify(mod.data.last)) {
        render();
        mod.data.last = mod.data.current;
        mod.time = Date.now();
      }
    })();
  };
  return mod;
});
