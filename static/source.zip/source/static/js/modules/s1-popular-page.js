/* eslint-disable comma-dangle */
(function(root, factory) {
  'use strict';

  if (typeof define === 'function' && define.amd) {
    define([], factory(root));
  } else if (typeof module === 'object' && module.exports) {
    module.exports = factory(root);
  } else {
    root.returnExports = factory(root);
  }
})(this, function(window) {
  'use strict';
  var _ = require('utils');
  var globals = require('globals');
  var document = window.document;
  var $ = window.$;

  var mod = {
    elements: {
      container: document.getElementById('js-popular-range'),
      pagnation: document.getElementById('js-popular-pagnation'),
    },
    data: {
      last: {},
      current: {},
    },
    frequency: 10 * 1000,
  };

  var VIS_ITEM_LEN = 5; //最受欢迎页面，每页显示的页面数量，目前为5
  var container = $(mod.elements.container);
  var pagnation = $(mod.elements.pagnation);

  var slideWidth;
  var pageCount;

  function numberToPercent(arr) {
    var total = arr.slice().reduce(function(a, b) {
      return a + b
    });
    var result =  arr.map(function(value) {
      return   parseInt(value / total * 100, 10)
    });

    result[0] = 100 - result.slice(1, -1).reduce(function(a, b) { return a + b }) - result.slice(-1);
    return result;
  }

  function render() {
   if (!mod.data.current.length) {
      return
   }

   var statisticsData = mod.data.current.slice().sort(function(a, b) {
        return b.value - a.value
    });
    var visitNumber = statisticsData.map(function(el) {
      return  el.value
    });
    var percent = numberToPercent(visitNumber);
    var mostPouplar = percent[0];
    container.html('');

    var html = statisticsData.map(function(data, index) {
      return [
        '<li class="popular-pages-items">',
          '<em>Top' + (index + 1) + '</em>',
          '<div class="bars" style="height:' + percent[index] / mostPouplar * 130 + 'px">',
            '<i>' + percent[index] + '%</i>',
          '</div>',
          '<span class="tip">' + data.name + '</span>',
        '</li>'
       ].join('');
    }).join('');


    container.html(html + html);
    var liWidth = 80;
    pageCount = Math.ceil(visitNumber.length / VIS_ITEM_LEN);//分页数
    slideWidth = liWidth * VIS_ITEM_LEN;
    container.css('width', liWidth * visitNumber.length);
    pagnation.html('');
    for (var page = 0; page < pageCount; page ++) {
      pagnation.append($('<li></li>'));
    }
  }

  function slidePopularRange(index) {
      var pageLi = $('li', pagnation);
      var width = $('.popular-pages-items').outerWidth();
      pageLi.removeClass('on').eq(index).addClass('on');
      container.animate({
        'marginLeft': - index * width * VIS_ITEM_LEN
      }, 1000, function() {
        if (index >= pageCount) {
          container.css({
            'marginLeft': 0,
          });
        }
      });
  }

  function init() {
    var index = 0;
    var pageIndex;
    if ($('li', container).length / 2 <= 5) {
      return
    }
    window.setInterval(function() {
      index = index % (pageCount + 1);
      slidePopularRange(index);
      index++;
    }, 5000);
  }

  mod.watch = function() {
    (function watch() {
      window.setTimeout(watch, mod.frequency);
      globals.userPopularPage = globals.userPopularPage || {};
      globals.userPopularPage.data = globals.userPopularPage.data || [];
      mod.data.current = globals.userPopularPage && globals.userPopularPage.data;
      if (JSON.stringify(mod.data.current) !== JSON.stringify(mod.data.last)) {
        mod.data.last = mod.data.current;
        mod.time = Date.now();
        render();
      }
    })();

    init();
  };
  return mod;
});
