/* eslint-disable comma-dangle */
(function(root, factory) {
  'use strict';

  if (typeof define === 'function' && define.amd) {
    define([], factory(root));
  } else if (typeof module === 'object' && module.exports) {
    module.exports = factory(root);
  } else {
    root.returnExports = factory(root);
  }
})(this, function(window) {
  'use strict';

  var _ = require('utils');
  var DESIGN_WIDTH = 1920;
  var document = window.document;
  var documentElement = document.documentElement;

  function resize(el) {
    el = _.dom(el)[0];
    return function() {
      var width = window.innerWidth;
      var height = window.innerHeight;
      var transform = [];
      var scale = (Math.max(width, height) / DESIGN_WIDTH);
      if (height > width) {
        transform.push('translateX(' + width + 'px)');
        transform.push('rotate(90deg)');
      }
      if (width < DESIGN_WIDTH) {
        transform.push('scale(' + scale + ')');
      }
      el.style.transform = transform.join(' ');
    };
  }

  return {
    bind: function(el) {
      var func = resize(el);
      func();
      _.on(window, 'resize load', func);
    }
  };
});

