/* eslint-disable comma-dangle */
(function(root, factory) {
  'use strict';

  if (typeof define === 'function' && define.amd) {
    define([], factory(root));
  } else if (typeof module === 'object' && module.exports) {
    module.exports = factory(root);
  } else {
    root.returnExports = factory(root);
  }
})(this, function(window) {
  'use strict';

  var _ = require('utils');
  var globals = require('globals');
  var document = window.document;
  var DISPLAY_LEN = 2;

  var $ = window.$;

  var mod = {
    elements: {
      container: document.getElementById('js-market-container'),
    },
    data: {
      last: {},
      current: {},
    },
    frequency: 10 * 1000,
  };

  var container = $(mod.elements.container);
  var pagnation = $('.market-pagnation');
  var pageCount = 0;
  var tabs = [];
  function init() {
    var slideIndex = 0;
    var pagnation = $('.market-pagnation');
    window.setInterval(function() {
      var li = $('#js-market-container li');
      var pageLi = $('li', pagnation);
      ++slideIndex;
      slideIndex = slideIndex % pageCount;
      pageLi.eq(slideIndex).addClass('on').siblings().removeClass('on');
      li.fadeOut(400);
      $('.' + tabs[slideIndex * 2 + 1]).fadeIn(400);
    }
    , 5000);
  }

  function render() {
    container.html('');
    pagnation.html('');
    pageCount = mod.data.current.length / DISPLAY_LEN;
    mod.data.current.forEach(function(datas, index) {
        tabs.push('tab-' + Math.floor(index / DISPLAY_LEN));
        var infoHtml = datas.data.map(function(info) {
           var unit = info.unit ? info.unit : (datas.unit ? datas.unit : '');
            return [
              '<div class="infor">',
                  '<div class="infor-tip">' + info.type + '</div>',
                ' <strong class="infor-detail">' + info.value + unit + '</strong>',
              '</div>'
            ].join('')
        }).join('');
        var child = [
          '<li class="market-list-item ' + tabs[index] + '">',
            '<div class="market-child">',
                '<div class="market-child-item describe">',
                    '<div class="icon">',
                        (datas.icon ? '<img src="' + datas.icon + '">' : ''),
                    '</div>',
                    '<span class="name">' + datas.name + '</span>',
                '</div>',
                '<div class="market-child-item">',
                   infoHtml,
                '</div>',
          '</div>',
        '</li>',
        ].join('');
        container.append(child);
    });

    for (var i = 0; i < pageCount; i++) {
      pagnation.append($('<li></li>'));
    }
    $('li', pagnation).eq(0).addClass('on').siblings().removeClass('on');
  }

  mod.watch = function() {
    (function watch() {
      window.setTimeout(watch, mod.frequency);
      mod.data.current = globals.s2Market && globals.s2Market.data;
      if (JSON.stringify(mod.data.current) !== JSON.stringify(mod.data.last)) {
        mod.data.last = mod.data.current;
        mod.time = Date.now();
        render();
      }
    })();
    init();
  };
  return mod;
});
