(function(root, factory) {
  'use strict';
  if (typeof define === 'function' && define.amd) {
    define([], factory);
  } else if (typeof exports === 'object') {
    module.exports = factory();
  } else {
    root.geoJSON = factory();
  }
})(this, function() {
  'use strict';
  var $ = window.common;

  function decode(json) {
      if (!json.UTF8Encoding) {
          return json;
      }
      var features = json.features;

      for (var f = 0; f < features.length; f++) {
          var feature = features[f];
          var coordinates = feature.geometry.coordinates;
          var encodeOffsets = feature.geometry.encodeOffsets;

          for (var c = 0; c < coordinates.length; c++) {
              var coordinate = coordinates[c];

              if (feature.geometry.type === 'Polygon') {
                  coordinates[c] = decodePolygon(
                      coordinate,
                      encodeOffsets[c]
                  );
              } else if (feature.geometry.type === 'MultiPolygon') {
                  for (var c2 = 0; c2 < coordinate.length; c2++) {
                      var polygon = coordinate[c2];
                      coordinate[c2] = decodePolygon(
                          polygon,
                          encodeOffsets[c][c2]
                      );
                  }
              }
          }
      }
      // Has been decoded
      json.UTF8Encoding = false;
      return json;
  }

  function decodePolygon(coordinate, encodeOffsets) {
      var result = [];
      var prevX = encodeOffsets[0];
      var prevY = encodeOffsets[1];

      for (var i = 0; i < coordinate.length; i += 2) {
          var x = coordinate.charCodeAt(i) - 64;
          var y = coordinate.charCodeAt(i + 1) - 64;

          // ZigZag decoding
          x = (x >> 1) ^ (-(x & 1));
          y = (y >> 1) ^ (-(y & 1));
          // Delta deocding
          x += prevX;
          y += prevY;

          prevX = x;
          prevY = y;
          // Dequantize
          result.push([x / 1024, y / 1024]);
      }

      return result;
  }

  function geoJSON() {
    if (!(this instanceof geoJSON)) {
      return new geoJSON();
    }
  }

  geoJSON.prototype.loadZip = function(uri, cacheKey) {
    cacheKey = cacheKey || uri;
    var render = this;
    var localForage;
    return Promise.resolve()
      .then(function() {
        var localForageModule = __uri('../vendors/localforage.min.js').replace(/\.js$/, '');
        return $.requirePromise(localForageModule)
          .then(function(module) {
            localForage = module;
          });
      })
      .then(function() {
        return localForage.getItem(cacheKey)
          .then(function(cache) {
            if (cache && cache.filename === uri) {
              return cache.blob;
            }
          });
      })
      .then(function(blob) {
        if (blob) {
          return blob;
        }
        return Promise.resolve(uri)
          .then(fetch)
          .then(function(response) {
            return response.blob();
          })
          .then(function(blob) {
            localForage.setItem(cacheKey, {
              filename: uri,
              blob: blob
            });
            return blob;
          });
      })
      .then(function(blob) {
        var jszipModule = __uri('../vendors/jszip.min.js').replace(/\.js$/, '');
        return $.requirePromise(jszipModule)
          .then(function(module) {
            var JSZip = module;
            var zip = new JSZip();
            return JSZip.loadAsync(blob);
          });
      })
      .then(function(zip) {
        var maps = {};
        var keys = Object.keys(zip.files);

        return Promise.all(keys.map(function(fileName) {

          if (zip.files[fileName].dir) {
            return;
          }

          var key = fileName.replace('.json', '');
          return zip.file(fileName)
            .async('string')
            .then(JSON.parse)
            .then(decode)
            .then(function(data) {
              maps[key] = data;
            });
        }))
        .then(function() {
          return maps;
        });
      })
      .then(function(maps) {
        return render.maps = maps;
      });
  };

  function getMapCoordinates(map) {
    if (map.coordinates) {
      return map;
    }
    var mapCoordinates = [];
    var features = map.features;
    features.forEach(function(feature) {
      var properties = feature.properties;
      var childNum = properties.childNum;
      var geometry = feature.geometry;
      var coordinates = geometry.coordinates;
      if (childNum === 1) {
        coordinates = [coordinates];
      }
      coordinates.forEach(function(coordinate, index) {
        mapCoordinates[index] = [];
        coordinate[0].forEach(function(coordinate, pointIndex) {
          mapCoordinates[index][pointIndex] = {
            lng: coordinate[0],
            lat: coordinate[1]
          };
        });
      });
    });

    var flatCoordinates = Array.prototype.concat.apply([], mapCoordinates);
    ['lng', 'lat'].forEach(function(type) {
      var typeOnly = flatCoordinates.map(function(coordinate) { return coordinate[type]; });
      var min = Math.min.apply(Math, typeOnly);
      var max = Math.max.apply(Math, typeOnly);
      var range = max - min;
      map[type] = {
        min: min,
        max: max,
        range: range
      };
    });
    map.coordinates = mapCoordinates;
    return map;
  }

  geoJSON.prototype.getPaper = geoJSON.getPaper = function(map, width, height) {
    if (!height) {
       height = width;
    }

    map = getMapCoordinates(map);
    var scale = Math.min(width / map.lng.range, height / map.lat.range);

    return {
      width: width,
      height: height,
      scale: scale,
      offsetX: - map.lng.min * scale,
      offsetY: - (90 - map.lat.max) * scale,
      mapWidth: map.lng.range * scale,
      mapHeight: map.lat.range * scale
    };
  };

  geoJSON.prototype.mapInfo =  function(map, paper) {
    var render = this;
    if (!map) {
      return null;
    }
    map = getMapCoordinates(map);
    var coordinates = map.coordinates;
    var scale = paper.scale;
    var offsetX = paper.offsetX;
    var offsetY = paper.offsetY;

    return {
      left: offsetX + map.lng.min * scale,
      right: offsetX + map.lng.max * scale,
      top: offsetY + (90 - map.lat.max) * scale,
      bottom: offsetY + (90 - map.lat.min) * scale
    };
  };

  geoJSON.prototype.getPath2D = function(map, paper) {
    var render = this;
    if (!map) {
      return null;
    }

    map = getMapCoordinates(map);
    var coordinates = map.coordinates;
    var scale = paper.scale;
    var offsetX = paper.offsetX;
    var offsetY = paper.offsetY;

    var pathDescription = map.coordinates.map(function(coordinates) {
      var path = coordinates.map(function(coordinate) {
        return (offsetX + (coordinate.lng) * scale) +
          ' ' +
          (offsetY + (90 - coordinate.lat) * scale);
      });
      return 'M' +  path.join('L') + 'Z';
    });
    return new Path2D(pathDescription.join(' '));
  };
  return geoJSON;
});
