/* eslint-disable comma-dangle */
(function(root, factory) {
  'use strict';

  if (typeof define === 'function' && define.amd) {
    define([], factory(root));
  } else if (typeof module === 'object' && module.exports) {
    module.exports = factory(root);
  } else {
    root.returnExports = factory(root);
  }
})(this, function(window) {
  'use strict';

  var _ = require('utils');
  var globals = require('globals');
  var MODULE_MAP = globals.MODULE_MAP;
  var setTimeout = window.setTimeout;

  function queryData(modules, callback) {
    if (_.type(modules) !== 'array') {
      modules = [modules];
    }

    var methods = modules.map(function(module) {
      return MODULE_MAP[module] && MODULE_MAP[module].method;
    });

    if (!methods.length) {
      return;
    }

    var requestStartTime = Date.now();

    var promise = new Promise(function(resolve) {
      _.getJSON(globals.API_BASE + methods.join('_') + (globals.API_BASE.indexOf('?') > -1 ? '&' : '?') + 'callback=?', function(data) {
        if (!data) {
          return;
        }

        var sysTime = +data.sysTime;
        // if (!globals.TIME_DIFF) {
          // globals.TIME_DIFF = requestStartTime - sysTime;
        // }

        if (!data || data.retCode !== '0') {
          console.error(new Date(data.sysTime),
            ' error occured while request: [' + methods.join(',') + ']: \n', data.resMsg);
          return;
        }

        var result = data.retObj || {};

        modules.forEach(function(module) {
          var method = MODULE_MAP[module].method;
          var data = result[method];
          var type = _.type(data);
          if (type !== 'null' && type !== 'undefined') {
            globals[module] = globals[module] || {};
            globals[module].data = data;
            globals[module].time = Date.now();
          }
        });

        resolve(data);
      });
    });

    if (callback) {
      return promise.then(callback);
    } else {
      return promise;
    }
  }


  function update(mods) {
    (function watch() {
      var now = Date.now();
      var modsNeedUpdate = [];
      mods.forEach(function(mod) {
        var frequency = MODULE_MAP[mod].frequency;
        var lastUpdate = (globals[mod] && globals[mod].time) || now;
        if (now - lastUpdate > frequency) {
          modsNeedUpdate.push(mod);
        }
      });

      if (modsNeedUpdate.length) {
        queryData(modsNeedUpdate);
      }

      setTimeout(watch, 500);
    })();
  }

  return {
    queryData: queryData,
    start: update
  };
});
