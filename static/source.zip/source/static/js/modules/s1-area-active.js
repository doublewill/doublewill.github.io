/* eslint-disable comma-dangle */
(function(root, factory) {
  'use strict';

  if (typeof define === 'function' && define.amd) {
    define([], factory(root));
  } else if (typeof module === 'object' && module.exports) {
    module.exports = factory(root);
  } else {
    root.returnExports = factory(root);
  }
})(this, function(window) {
  'use strict';

  var _ = require('utils');
  var globals = require('globals');
  var document = window.document;
  var geoJSON = require('geojson');
  var $ = window.jQuery;

  var mod = {
    elements: {
      area: document.getElementById('js-area-active'),
      map: document.getElementById('js-map-container'),
    },
    data: {
      last: {},
      current: {},
    },
    frequency: 30 * 1000,
  };


  var sortData = [];
  var CONFIG = {
    AREA_DISPLAY_ITEMS: 10,
    // 区域活跃度 彩条最大宽度
    AREA_WIDTH: 290,
    // 初始状态  区域地图画布
    initStyle: {
      lineWidth: 1,
      lineColor: '#23c3cf',
      fillColor: 'rgba(75,145,233,0.77)',
    },
    // 高活跃度 区域画布
    activeStyle: {
      lineWidth: 3,
      lineColor: '#fbd336',
      fillColor: '#26c9ce',
    },
     // 区域活跃轮播频率  /ms
    frequency: 5 * 1000,
    offsetTop: 100,
  };

  var areaOrder = [
    '济南',
    '德州',
    '聊城',
    '菏泽',
    '枣庄',
    '济宁',
    '泰安',
    '莱芜',
    '临沂',
    '日照',
    '青岛',
    '威海',
    '烟台',
    '潍坊',
    '东营',
    '滨州',
    '淄博',
  ];

  var cityMapTable = {
    '济南': '济南市',
    '德州': '德州市',
    '聊城': '聊城市',
    '菏泽': '菏泽市',
    '枣庄': '枣庄市',
    '济宁': '济宁市',
    '泰安': '泰安市',
    '莱芜': '莱芜市',
    '临沂': '临沂市',
    '日照': '日照市',
    '青岛': '青岛市',
    '威海': '威海市',
    '烟台': '烟台市',
    '潍坊': '潍坊市',
    '东营': '东营市',
    '滨州': '滨州市',
    '淄博': '淄博市',
  };

  var area = mod.elements.area;
  var map = mod.elements.map;
  var canvas = document.createElement('canvas');
  map.appendChild(canvas);
  var context = canvas.getContext('2d');
  var helperCanvas = canvas.cloneNode();
  var rect = map.getBoundingClientRect();
  var width = rect.width;
  var height = rect.height;
  var isProvMapDrawed = false;
  canvas.width = width;
  canvas.height = height;
  context.translate(0.5, 0.5);

  var geojson = new geoJSON();
  var geoPaper;
  var cityPaths = {};
  var isMapLoaded;
  var isToggleClass = false;
  var mapInfo = {};

  function drawPovinceMap() {
    if (isProvMapDrawed) {
      return;
    }
    var maps = geojson.maps;
    var proviceMap = maps['山东省'];
    if (!geoPaper) {
      geoPaper = geoJSON.getPaper(proviceMap, width, height);
      // 居中
      var offsetX = (width - geoPaper.mapWidth) / 2;
      var offsetY = (height - geoPaper.mapHeight) / 2;
      geoPaper.offsetX += offsetX;
      geoPaper.offsetY += offsetY;
    }

    context.save();
    context.strokeStyle = CONFIG.initStyle.lineColor;
    context.fillStyle = CONFIG.initStyle.fillColor;
    context.lineWidth = CONFIG.initStyle.lineWidth;

    Object.keys(maps).forEach(function(mapName) {
      if (mapName === '山东省') {
        return;
      }
      if (!cityPaths[mapName]) {
        cityPaths[mapName] = geojson.getPath2D(maps[mapName], geoPaper);
        mapInfo[mapName] = geojson.mapInfo(maps[mapName], geoPaper);
      }
      var path = cityPaths[mapName];
      context.stroke(path);
      context.fill(path);
    });

    context.restore();

    if (canvas.toBlob) {
      return new Promise(function(resolve) {
        canvas.toBlob(function(blob) {
          var bg = window.URL.createObjectURL(blob);
          map.style.backgroundImage = 'url(' + bg + ')';
          isProvMapDrawed = true;
          resolve();
        });
      });
    }

    else {
      var bg = helperCanvas.toDataURL();
      map.style.backgroundImage = 'url(' + bg + ')';
      isProvMapDrawed = true;
    }
  }

  function drawCityMap(city) {
    var path = cityPaths[city];
    var pos = mapInfo[city];
    var cityName = city.substr(4, 2);
    var currentCity = sortData.filter(function(data) {
      return data.city === cityName;
    })[0];

    context.save();
    context.lineWidth = CONFIG.activeStyle.lineWidth;
    context.strokeStyle = CONFIG.activeStyle.lineColor;
    context.fillStyle = CONFIG.activeStyle.fillColor;
    context.fill(path);
    context.stroke(path);
    context.restore();

    var center = {
      x: (pos.left + pos.right) / 2,
      y: (pos.top + pos.bottom) / 2
    };

  //文字宽度
    var txtWidth = Math.max(
        context.measureText(currentCity.city).width,
        context.measureText(currentCity.zxrs).width
    );

    var offsetTop = CONFIG.offsetTop + 80;
    var dotLeft = 0;
    var offsetLeft = 0;
    if (pos.right >= width / 2) {  // 当前地市处于地图 居右
      offsetLeft = pos.left - txtWidth;
      dotLeft = pos.left + txtWidth;
    }
    else {   // 当前地市处于地图 居左
      offsetLeft = pos.right;
      dotLeft = offsetLeft;
    };

    context.save();
    context.beginPath();
    context.lineWidth = 1;
    context.strokeStyle = CONFIG.activeStyle.lineColor;
    context.fillStyle = CONFIG.activeStyle.lineColor;
    context.moveTo(center.x, center.y);
    context.lineTo(dotLeft, offsetTop);
    context.stroke();

    //地市以及在线人数
    context.save();
    context.beginPath();
    context.fillStyle = '#fff';
    context.font = '24px microsoft yahei';
    context.fillText(currentCity.city, dotLeft - txtWidth * 2, offsetTop - 60);
    context.font = '20px microsoft yahei';
    context.fillText(currentCity.zxrs, dotLeft - txtWidth * 2, offsetTop - 20);

    //圆点
    context.moveTo(dotLeft, offsetTop);
    context.arc(dotLeft, offsetTop, 3, 0, Math.PI * 2);
    context.fill();

    //底部横线
    context.lineTo(dotLeft - txtWidth * 2, offsetTop);
    context.stroke();
    context.restore();
 }

  function drawMap(city) {
    var promise = Promise.resolve();
    if (!isMapLoaded) {
      promise = promise
        .then(function() {
          var mapZipPath = '../../../data/maps.zip'.replace('../../../', '');
          return geojson.loadZip(mapZipPath, 'maps');
        })
        .then(function() {
          isMapLoaded = true;
        });
    }

    return promise
      .then(function() {
        context.clearRect(0, 0, width, height);
      })
      .then(drawPovinceMap)
      .then(function() {
        drawCityMap('山东省-' + city);
      });
  }

  function parseData(data) {
    var maxValue = _.max(data, 'hyrs') || 1;
    var parsedData = {};

    data.forEach(function(data) {
      parsedData[data.city] = {
        city: data.city,
        hyrs: data.hyrs,
        zxrs: data.zxrs,
        percentage: data.hyrs / maxValue,
      };
    });
    return parsedData;
  }

  function sortCityList(areaOrder, data) {
    return areaOrder.map(function(area) {
       return data.filter(function(d) {
        return d.city === area;
      })[0]
    });
  }

  function showCity(index) {

    if (!mod.data.current.length) {
      return
    }

    index %= areaOrder.length;
    var parsedData = parseData(sortData);
    var cityName = sortData[index].city;
    var height = $('.statics-bar', $(area)).outerHeight();

    if (index <= sortData.length - CONFIG.AREA_DISPLAY_ITEMS) {
      area.style.top = - height * index + 'px';
    }

    if (index >= sortData.length - 1) {
      area.style.top = - height * (sortData.length - CONFIG.AREA_DISPLAY_ITEMS) + 'px';
    }

    $('li', $(area)).eq(index).addClass('active').siblings().removeClass('active');

    window.setTimeout(function() {
      $('.online', $(area)).hide().eq(index).slideDown(1000);
    }, 500);

    drawMap(cityMapTable[cityName])
      .then(function() {
        return new Promise(function(resolve) {
          window.setTimeout(resolve, CONFIG.frequency);
        });
      })
      .then(function() {
        showCity(++index);
      })
      .catch(function(e) {
        console.trace(e);
      });
  };

  function init() {
    if (!mod.data.current.length) {
      return
    }
      sortData = sortCityList(areaOrder, mod.data.current);
      areaOrder.forEach(function(city, index) {
          var data = parseData(sortData)[city];
          var className = isToggleClass ? 'toggleBg' : '';
          var li = document.createElement('li');
          isToggleClass = !isToggleClass;
          li.className = className;
          li.innerHTML = [
            '<div class="area-box">',
              '<div class="statics-bar">',
                '<label class="city">' + data.city + '</label>',
                '<span class="bar" style="width:' + data.percentage * CONFIG.AREA_WIDTH + 'px"></span>',
                '<em class="number">' + data.hyrs + '</em>',
              '</div>',
              '<div class="online">',
                '<div class="online-count">',
                '<span>当日活跃人数</span>',
                '<em class="counter">' + data.hyrs + '</em>',
                '</div>',
              '</div>',
            '</div>',
        ].join('');
        area.appendChild(li);
      });
  }

  mod.watch = function() {
    (function watch() {
      window.setTimeout(watch, mod.frequency);
      mod.data.current = globals.areaActive && globals.areaActive.data;
      mod.data.last = mod.data.current;
      mod.time = Date.now();
    })();
    init();
    showCity(0);
  };
  return mod;
});
