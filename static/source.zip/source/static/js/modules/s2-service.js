/* eslint-disable comma-dangle */
(function(root, factory) {
  'use strict';

  if (typeof define === 'function' && define.amd) {
    define([], factory(root));
  } else if (typeof module === 'object' && module.exports) {
    module.exports = factory(root);
  } else {
    root.returnExports = factory(root);
  }
})(this, function(window) {
  'use strict';

  var _ = require('utils');
  var globals = require('globals');
  var document = window.document;
  var Highcharts = window.Highcharts;

  var mod = {
    elements: {
      container: document.getElementById('js-service-container'),
    },
    data: {
      last: {},
      current: {},
    },
    frequency: 10 * 1000,
 };

 var colors = ['#ffc732', '#a5cc4c', '#ff7d4a', '#4bb5eb', '#4a77e0'];
 var checkChart = new Highcharts.Chart({
        chart: {
            renderTo: 'js-service-container',
            type: 'pie',
            options3d: {
              enabled: true,
              alpha: 45,
              beta: 30,
              fitToPlot: true,
              frame: {
                bottom: {
                  color: '#f00',
                  size: 10,
                },
              },
            },
            backgroundColor: 'transparent',
            ignoreHiddenSeries: false,
        },
        credits: {
            text: '',
            href: '',
            enabled: false,
        },
        colors: colors,
        title: null,
        tooltip: {
          enabled: false,
           formatter: function() {
              return Highcharts.numberFormat(this.percentage, 0) + '%';
            },
            shadow: false,
            color: '#fff',
        },
        plotOptions: {
            pie: {
              allowPointSelect: false,
              depth: 10,
              dataLabels: {
                enabled: true,
                format: '<b style="font-size:16px;font-weight:normal;white-space:normal;word-break:break-all;">{point.name}</b>',
                style: {
                  color: '#fff',
                },
                x: 10,
                y: 5,
                distance: 2,
              },
              center: ['50%', '50%'],
              slicedOffset: 15,
              size: 165,
            },
        },
        series: [
            {
              type: 'pie',
              name: '',
              shadow: false,
              data: [
              ],
            }
        ],
    });

  function formatSeriesData(datas, selectedIndex) {
    var result = datas.map(function(data, index) {
       var sliced = false;
        if (selectedIndex === index) {
            sliced = true;
        }
        return {
          name: data.name + ' ' + _.scientificNum(data.value) + '次',
          y: data.value,
          sliced: sliced,
        };
      });
    return result;
  }

  function render() {
    var data = mod.data.current;
    checkChart.series[0].setData(formatSeriesData(data, 0));
  }

  function init() {
    (function(count) {
      setInterval(function() {
        ++count;
        count = count % mod.data.current.length;
        var datas = formatSeriesData(mod.data.current, count);
       checkChart.series[0].setData(datas);
      }, 10000);
    })(0);
  }

  mod.watch = function() {
    init();
    (function watch() {
      window.setTimeout(watch, mod.frequency);
      mod.data.current = globals.s2Service && globals.s2Service.data;
      if (JSON.stringify(mod.data.current) !== JSON.stringify(mod.data.last)) {
        render();
        mod.data.last = mod.data.current;
        mod.time = Date.now();
      }
    })();
  };
  return mod;
});
