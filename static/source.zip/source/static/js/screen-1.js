/* eslint-disable comma-dangle */
(function(window) {
  'use strict';

  var dependencies = [
    'geojson',
  ];

  var data = [
    'time',
    'activityUserMonthly',
    'activityUserAccumulate',
    'userScale',
    'userPic4gyhstl',
    'userPopularPage',
    'userStartTimes',
    'useTimeAvg',
    'areaActive',
  ];

  var modules = [
    'clock',
    's1-active-monthly',
    's1-active-accumulate',
    's1-user-scale',
    's1-fourgyhstl',
    's1-popular-page',
    's1-start-times',
    's1-time-avg',
    's1-area-active',
  ];

  var screen = window.common.getScreen(dependencies, data, modules);
  var requirePromise = window.common.requirePromise;

  Promise.resolve()
    .then(screen.loadDependencies.bind(screen))
    .then(screen.startDataWatch.bind(screen))
    .then(function() {
      // return require('clock').watch();
    })
    .then(screen.queryData.bind(screen))
    .then(screen.loadModules.bind(screen))
    .then(function() {
      return require('resize').bind('#js-container');
    })
    .catch(function(e) {
      console.trace(e);
    });
})(this);
