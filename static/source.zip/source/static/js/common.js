/* eslint-disable comma-dangle */
(function(root, factory) {
  'use strict';

  // if (typeof define === 'function' && define.amd) {
  //   define([], factory(root));
  // } else if (typeof module === 'object' && module.exports) {
  //   module.exports = factory(root);
  // } else {
    root.common = factory(root);
  // }
})(this, function(window) {
  'use strict';

  var API_BASE = window.API_BASE;
  /* eslint-disable */
  var resMap = __RESOURCE_MAP__;
  /* eslint-enable */

  var requirePaths = {};
  for (var file in resMap.res) {
    if (resMap.res.hasOwnProperty(file)) {
      var type = resMap.res[file].type;
      var uri = resMap.res[file].uri;
      var re = /\/js\/modules\/(.*)\.js$/i;
      if (type === 'js' && file.match(re) && uri.match(re)) {
        var mod = file.match(re)[1];
        var filename = uri.match(re)[1];
        if (mod !== filename) {
          requirePaths[mod] = filename;
        }
      }
    }
  }

  require.config({
    baseUrl: 'static/js/modules/',
    paths: requirePaths
  });

  function requireQueue(modules) {
    if (!Array.isArray(modules)) {
      return requirePromise(modules);
    }
    var mods = [];
    return new Promise(function(resolve) {
      (function loadMod() {
        require([modules.shift()], function() {
          mods.push.apply(mods, arguments);
          if (modules.length) {
            loadMod();
          } else {
            resolve(mods);
          }
        });
      })();
    });
  }

  function requirePromise(modules) {
    var isArray = Array.isArray(modules);
    modules = isArray ? modules : [modules];
    return new Promise(function(resolve) {
      require(modules, function(module) {
        resolve(isArray ? Array.from(arguments) : module);
      });
    });
  }

  var commonMods = [
    'utils',
    'globals',
    'clock',
    'resize',
    'fullscreen',
    'data-loader',
  ];

  function Screen(dependencies, data, modules) {
    this.dependencies = commonMods.concat(dependencies || []);
    this.data = data;
    this.modules = modules;
  }

  Screen.prototype.loadDependencies = function() {
    return requireQueue(this.dependencies).then(function() {
      require('globals').API_BASE = API_BASE;
      require('fullscreen').bind();
    });
  };

  Screen.prototype.startDataWatch = function() {
    return require('data-loader').start(this.data);
  };

  Screen.prototype.queryData = function() {
    return require('data-loader').queryData(this.data);
  };

  Screen.prototype.loadModules = function() {
    var _ = require('utils');
    var screen = this;
    return Promise.resolve(screen.modules)
      .then(requirePromise)
      .then(function(modules) {
        return Promise.all(modules.map(function(module) {
          return module.watch();
        }));
      });
  };

  return {
    requireQueue: requireQueue,
    requirePromise: requirePromise,
    API_BASE: API_BASE,
    mods: commonMods,
    getScreen: function(dependencies, data, modules) {
      return new Screen(dependencies, data, modules);
    },
  };
});
