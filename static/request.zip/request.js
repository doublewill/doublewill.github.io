import axios from 'axios'
import {CORS, YQL} from './config'
import { cloneDeep, isEqual } from 'lodash'
import pathToRegexp from 'path-to-regexp'
import { Modal } from 'antd'

let cancelObj = {}

const fetch = (options) => {
  let {
    method,
    data,
    url,
  } = options

  const cloneData = cloneDeep(data)
  try {
    let domin = ''
    if (url.match(/[a-zA-z]+:\/\/[^/]*/)) {
      domin = url.match(/[a-zA-z]+:\/\/[^/]*/)[0]
      url = url.slice(domin.length)
    }
    const match = pathToRegexp.parse(url)
    url = pathToRegexp.compile(url)(data)
    for (let item of match) {
      if (item instanceof Object && item.name in cloneData) {
        delete cloneData[item.name]
      }
    }
    url = domin + url
  } catch (e) {
    Modal.error({
      title: '提示',
      content: e.message,
      okText: '关闭',
    })
  }

  // 利用axios的cancel功能，将超过1秒的未返回的重复提交处理
  return new Promise((resolve, reject) => {
    let cancel
    const httpServer = axios.create({
      responseType: 'json',
      cancelToken: new axios.CancelToken((c) => {
        // record the cancel function
        cancel = c
      }),
    })

    httpServer.interceptors.request.use((config) => {
      if (cancelObj[url] && cancelObj[url].hasOwnProperty('cancel')) {
        // ! 采用策略，第一次没返回，取消第二次，
        // 另一种策略是，覆盖策略，第一次没返回，取消第一次，以最后一次为准
        // cancelObj[url]('request cancelled')
        // 第一次没返回，取消第二次，
        if (isEqual(cloneData, cancelObj[url].data)) {
          cancel('request cancelled')
        }
        cancelObj[url] = {
          cancel,
          data: cloneData,
        }
      } else {
        cancelObj[url] = {
          cancel,
          data: cloneData,
        }
      }
      return config
    }, (error) => {
      return Promise.reject(error)
    })

    httpServer.interceptors.response.use((response) => {
      cancelObj[response.config.url] = null
      return response
    }, (error) => {
      return Promise.reject(error)
    })

    switch (method.toLowerCase()) {
      case 'get':
        httpServer.get(url, {
          params: cloneData,
        }).then(res => resolve(res)).catch(err => reject(err))
        break
      case 'delete':
        httpServer.delete(url, {
          data: cloneData,
        }).then(res => resolve(res)).catch(err => reject(err))
        break
      case 'post':
        httpServer.post(url, cloneData).then(res => resolve(res)).catch(err => reject(err))
        break
      case 'put':
        httpServer.put(url, cloneData).then(res => resolve(res)).catch(err => reject(err))
        break
      case 'patch':
        httpServer.patch(url, cloneData).then(res => resolve(res)).catch(err => reject(err))
        break
      default:
        httpServer(options).then(res => resolve(res)).catch(err => reject(err))
        break
    }
  })
}

let requestUrl = [] // 1秒内请求url列表
let saveTime = 1000 // 间隔时间

export default function request(options) {
  if (options.url && options.url.indexOf('//') > -1) {
    const origin = `${options.url.split('//')[0]}//${options.url.split('//')[1].split('/')[0]}`
    if (window.location.origin !== origin) {
      if (CORS && CORS.indexOf(origin) > -1) {
        options.fetchType = 'CORS'
      } else if (YQL && YQL.indexOf(origin) > -1) {
        options.fetchType = 'YQL'
      } else {
        options.fetchType = 'JSONP'
      }
    }
  }

  // 1秒时间内重复请求，直接忽略
  // 筛选在缓存时间内未过期请求 重新赋值缓存请求数组 新数组与当前请求url 匹配
  // 如果有相等项 则判断为重复提交的请求 直接return
  let nowTime = new Date().getTime()
  requestUrl = requestUrl.filter((item) => {
    return (item.setTime + saveTime) > nowTime
  })
  let sessionUrl = requestUrl.filter((item) => {
    // 同样的url，并且参数相同时，才认为是重复的请求
    return item.url === options.url && isEqual(item.data, options.data)
  })

  if (sessionUrl.length > 0) {
    // console.log(options.url + '请求重复 中断请求!')
    // ! 防止return被框架捕获，抛出错误信息
    throw('')
  }

  requestUrl.push({
    url: options.url,
    setTime: new Date().getTime(),
    data: options.data,
  })

  return fetch(options).then((response) => {
    // console.log('响应返回')
    let {statusText, status} = response
    if (response.status == 403) {
      // 清除本地缓存
      localStorage.clear();
      window.location = `${location.origin}/login`
    }
    let data = options.fetchType === 'YQL' ? response.data.query.results.json : response.data

    // bad gateway
    if (status == 502) {
      statusText = '网络存在异常，请稍等或者刷新页面！'
    } else if (status == 504) {
      statusText = '服务器错误，系统性能存在问题，请联系管理员！'
    }

    return {
      success: true,
      message: statusText,
      statusCode: status,
      ...data,
    }
  }).catch((error) => {
    // console.log('响应拒绝')
    // console.log(error)
    const { message } = error
    if (message === 'request cancelled') {
      // return { success: false, error: '请不要重复点击提交', message: '请不要重复点击提交' }
      // ! 防止return被框架捕获，抛出错误信息
      throw ('')
    }

    const { response, config } = error
    // * 在发生其他异常时，也删除当前url的cancelObj
    cancelObj[config.url] = null

    if (response.status == 403) {
      //清除本地缓存
      localStorage.clear();
      window.location = `${location.origin}/login`
    }
    let msg
    let statusCode
    if (response && response instanceof Object) {
      const {data, statusText} = response
      statusCode = response.status
      msg = data ? data.message : statusText
    } else {
      statusCode = 600
      msg = error.message || 'Network Error'
    }

    // bad gateway
    if (statusCode == 502) {
      msg = '网络存在异常，请稍等或者刷新页面！'
    } else if (statusCode == 504) {
      msg = '服务器错误，系统性能存在问题，请联系管理员！'
    }

    return {success: false, statusCode, message: msg, error: msg}
  })
}
